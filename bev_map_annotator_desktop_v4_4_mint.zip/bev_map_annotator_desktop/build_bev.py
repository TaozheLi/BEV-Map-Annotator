"""Build a metric ground BEV from an ordered point-cloud sequence."""
import argparse,json,re,time
from pathlib import Path
import numpy as np
from PIL import Image
from pointcloud_io import read_point_cloud

def ground_points(xyz):
    points=xyz[np.isfinite(xyz).all(1)&(np.linalg.norm(xyz[:,:2],axis=1)<40)&(xyz[:,2]>-3.5)&(xyz[:,2]<-.6)]
    if len(points)<100:return np.zeros(len(xyz),bool)
    rng=np.random.default_rng(0);sample=points[rng.choice(len(points),min(3000,len(points)),replace=False)]
    best=None;score=0
    for _ in range(40):
        a,b,c=sample[rng.choice(len(sample),3,replace=False)];normal=np.cross(b-a,c-a);norm=np.linalg.norm(normal)
        if norm<1e-6:continue
        normal/=norm
        if abs(normal[2])<.94:continue
        offset=-normal@a;support=np.count_nonzero(abs(sample@normal+offset)<.15)
        if support>score:score=support;best=(normal,offset)
    if best is None:return np.zeros(len(xyz),bool)
    normal,offset=best
    return np.isfinite(xyz).all(1)&(np.linalg.norm(xyz[:,:2],axis=1)<40)&(abs(xyz@normal+offset)<.15)


def natural_key(path):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r'(\d+)',path.as_posix())]


def collect_paths(root, pattern='**/*.pcd', start=None, end=None):
    from collections import Counter
    root=Path(root).resolve();paths=sorted([p for p in root.glob(pattern) if p.is_file() and p.suffix.lower() in ('.pcd','.bin')],key=lambda p:natural_key(p.relative_to(root)))
    if not paths:raise ValueError(f'No PCD/BIN files matched {pattern} in {root}')
    # Preserve legacy frame IDs where unique; disambiguate duplicates by relative path.
    short=[p.parent.name if p.stem=='lidar' else p.stem for p in paths];counts=Counter(short)
    names=[name if counts[name]==1 else p.relative_to(root).with_suffix('').as_posix() for name,p in zip(short,paths)]
    if len(set(names))!=len(names):
        names=[p.relative_to(root).as_posix() for p in paths]
    def match(value):
        value=str(value).replace('\\','/')
        relative=[p.relative_to(root).as_posix() for p in paths];without=[p.relative_to(root).with_suffix('').as_posix() for p in paths]
        hits=[i for i in range(len(paths)) if value in (names[i],relative[i],without[i])]
        if len(hits)==1:return hits[0]
        hits=[i for i,n in enumerate(short) if n==value or (value.isdigit() and n.isdigit() and int(n)==int(value))]
        if len(hits)==1:return hits[0]
        if len(hits)>1:raise ValueError(f'Ambiguous frame {value}; use a relative path such as {relative[hits[0]]}')
        raise ValueError(f'Frame {value} not found in matched files')
    i=match(start) if start else 0;j=match(end)+1 if end else len(paths)
    if j<=i:raise ValueError('End frame precedes start frame')
    return list(zip(names[i:j],paths[i:j]))


def load_poses(path):
    data=json.loads(Path(path).read_text());result={}
    for row in data:
        frame=str(row['frame']);T=np.asarray(row['T_world_from_lidar'],float)
        if T.shape!=(4,4) or not np.isfinite(T).all() or not np.allclose(T[3],[0,0,0,1]) or not np.allclose(T[:3,:3].T@T[:3,:3],np.eye(3),atol=1e-4) or not np.isclose(np.linalg.det(T[:3,:3]),1,atol=1e-4):raise ValueError(f'Invalid rigid pose for {frame}')
        if frame in result:raise ValueError(f'Duplicate pose {frame}')
        result[frame]=T
    return result


def default_output(root):
    """Allocate a unique map path without creating or overwriting an existing map."""
    from datetime import datetime
    name=Path(root).resolve().name or 'clouds'
    base=Path(__file__).resolve().parent/'generated_maps'
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    return base/f'{name}_{stamp}_{time.time_ns() % 1000000:06d}'


def build(root,output=None,pattern='**/*.pcd',start=None,end=None,stride=10,resolution=.15,poses_path=None,already_world=False,progress=None,cancelled=None):
    if stride<1 or resolution<=0 or not np.isfinite(resolution):raise ValueError('Positive stride/resolution required')
    if already_world:raise ValueError('Already-world clouds require a world-aware ground extractor; use local LiDAR scans with poses instead')
    if cancelled and cancelled():raise InterruptedError('Cancelled')
    frames=collect_paths(root,pattern,start,end);output=Path(output).resolve() if output else default_output(root)
    if output.exists() and any(output.iterdir()):raise ValueError('Choose a new empty map output folder to preserve prior maps/annotations')
    poses=load_poses(poses_path) if poses_path else None
    if poses is not None:
        missing=[name for name,_ in frames if name not in poses]
        if missing:raise ValueError(f'Missing poses: {missing[:5]}')
    else:
        if progress:progress('KISS-ICP automatic alignment (default)',0,len(frames))
        try:
            from kiss_icp.kiss_icp import KissICP
            from kiss_icp.config import KISSConfig
        except ImportError as exc:raise RuntimeError('Automatic alignment needs kiss-icp. Install requirements.txt or supply --poses.') from exc
        cfg=KISSConfig();cfg.data.max_range=40.;cfg.data.min_range=2.;cfg.data.deskew=True;cfg.registration.max_num_threads=4;cfg.mapping.voxel_size=.4;slam=KissICP(cfg)
    points=[];values=[];pose_records=[];used=[];intensity_fields=set();timed=0;output.mkdir(parents=True,exist_ok=True)
    for index,(name,path) in enumerate(frames):
        if cancelled and cancelled():raise InterruptedError('Cancelled')
        if poses is not None and index%stride:continue
        fields,_=read_point_cloud(path);xyz=np.column_stack([fields[k] for k in 'xyz']);finite=np.isfinite(xyz).all(1)
        if poses is None:
            timing=path.with_name('lidar_timing.npz');relative=np.zeros(len(xyz),float);usable=finite.copy()
            if timing.exists() and 'column' in fields:
                with np.load(timing) as d:
                    ts=d['column_timestamp_ns'].astype(float);ids=d['measurement_id'].astype(int)
                    if not len(ts) or (ids<0).any():raise ValueError('Invalid per-column timing')
                    lookup=np.full(max(int(ids.max())+1,1024),np.nan);lookup[ids]=ts;columns=np.asarray(fields['column'],int);valid=(columns>=0)&(columns<len(lookup));times=np.full(len(columns),np.nan);times[valid]=lookup[columns[valid]];usable&=np.isfinite(times);relative[usable]=(times[usable]-ts.min())/max(float(np.ptp(ts)),1);timed+=1
            if not usable.any():raise ValueError(f'No valid points in {path}')
            slam.register_frame(xyz[usable],relative[usable]);T=np.asarray(slam.last_pose).copy();pose_records.append({'frame':name,'T_world_from_lidar':T.tolist()})
        else:T=poses[name]
        if index%stride==0:
            keep=ground_points(xyz)
            field='reflectivity' if 'reflectivity' in fields else 'intensity' if 'intensity' in fields else None
            if field is None:raise ValueError(f'{path}: reflectivity/intensity field required')
            intensity=np.asarray(fields[field]);keep&=np.isfinite(intensity);intensity_fields.add(field)
            points.append(xyz[keep]@T[:3,:3].T+T[:3,3]);values.append(intensity[keep]);used.append(name)
        if progress:progress(f'Alignment / ground: {index+1}/{len(frames)}',index+1,len(frames))
    xyz=np.concatenate(points);intensity=np.concatenate(values)
    if len(xyz)<100:raise ValueError('Too few ground points. This extractor expects local LiDAR Z-up, ground roughly -1.75m below sensor.')
    lowxy=xyz[:,:2].min(0)-3;highxy=xyz[:,:2].max(0)+3;width,height=np.ceil((highxy-lowxy)/resolution).astype(int)+1
    if width*height>30_000_000:raise ValueError('Map exceeds 30 million pixels; use a coarser resolution or shorter range')
    x=np.floor((xyz[:,0]-lowxy[0])/resolution).astype(int);y=height-1-np.floor((xyz[:,1]-lowxy[1])/resolution).astype(int);count=np.zeros((height,width),np.uint32);mean=np.zeros((height,width),np.float32);np.add.at(count,(y,x),1);np.add.at(mean,(y,x),intensity);valid=count>0;mean[valid]/=count[valid];lo,hi=np.quantile(mean[valid],[.02,.98]);gray=np.clip((mean-lo)/max(float(hi-lo),1e-6),0,1);rgb=np.zeros((height,width,3),np.uint8)+[14,22,34];rgb[valid]=(55+gray[valid,None]*190).astype(np.uint8)
    Image.fromarray(rgb.astype(np.uint8)).save(output/'ground_reflectivity.png');np.savez_compressed(output/'ground_map.npz',mean_reflectivity=mean,count=count,resolution_m=resolution,minimum_world_xy=lowxy,height_pixels=height)
    meta={'coordinate_frame':'provided_SLAM_world' if poses is not None else 'first_scan_local_SLAM_world','resolution_m':resolution,'minimum_world_xy':lowxy.tolist(),'image_size':[int(width),int(height)],'source_frames':used,'data_root':str(Path(root).resolve()),'input_pattern':pattern,'source_files':{name:str(path.relative_to(Path(root).resolve())) for name,path in frames},'start':start,'end':end,'stride':stride,'alignment':'provided poses' if poses is not None else 'KISS-ICP 1.3.0','deskew_frames':timed,'ground_extraction':'local near-horizontal RANSAC, range40m, z -3.5..-0.6m, threshold0.15m','intensity_fields':sorted(intensity_fields),'warning':'Ground is not a road semantic label. Inspect SLAM drift before annotating.'}
    (output/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');(output/'annotations.geojson').write_text(json.dumps({'type':'FeatureCollection','features':[]},indent=2)+'\n')
    if poses is None:allposes=pose_records
    else:allposes=[{'frame':name,'T_world_from_lidar':poses[name].tolist()} for name,_ in frames]
    (output/'poses.json').write_text(json.dumps(allposes,indent=2)+'\n')
    if progress:progress(f'BEV ready: {output}',len(frames),len(frames))
    return output


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cloud-dir',type=Path,required=True);p.add_argument('--output',type=Path,help='Optional; defaults to generated_maps/<capture>_<timestamp>/');p.add_argument('--pattern',default='**/*.pcd');p.add_argument('--start');p.add_argument('--end');p.add_argument('--stride',type=int,default=10);p.add_argument('--resolution',type=float,default=.15);p.add_argument('--poses',type=Path,help='Optional pose override; default uses KISS-ICP automatically');a=p.parse_args();build(a.cloud_dir,a.output,a.pattern,a.start,a.end,a.stride,a.resolution,a.poses,progress=lambda s,*_:print(s,flush=True))
