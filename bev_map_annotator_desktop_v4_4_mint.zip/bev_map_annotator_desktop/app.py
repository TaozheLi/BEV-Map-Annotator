"""Local Tkinter BEV map annotation. No HTTP server or browser."""
import argparse
import copy
import json
import time
import queue
import threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter import font as tkfont
from PIL import Image, ImageTk, ImageOps
from geometry import validate

COLORS={'drivable_area':'#76ea9c','divider':'#ffe34c','ped_crossing':'#ff86cf','boundary':'#55d6ff','stopline':'#ff976f'}


def pixel_to_world(p, meta):
    u,v=p;r=meta['resolution_m'];x,y=meta['minimum_world_xy'];h=meta['image_size'][1]
    return [x+(u+.5)*r,y+(h-1-v+.5)*r]


def world_to_pixel(p, meta):
    x,y=p;r=meta['resolution_m'];xmin,ymin=meta['minimum_world_xy'];h=meta['image_size'][1]
    return [(x-xmin)/r-.5,h-1-(y-ymin)/r+.5]


def save_annotation(annotation, output, expected_revision):
    validate(annotation)
    actual=output.stat().st_mtime_ns if output.exists() else 0
    if actual!=expected_revision:raise ValueError('The output changed in another editor. Use Save As to preserve both versions.')
    output.parent.mkdir(parents=True,exist_ok=True)
    if output.exists():
        backup=output.parent/'backups';backup.mkdir(exist_ok=True)
        (backup/f'{output.stem}.{time.time_ns()}.geojson').write_bytes(output.read_bytes())
    result=copy.deepcopy(annotation);result['review_status']='draft';result['updated_unix']=time.time()
    temp=output.with_suffix('.tmp');temp.write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n');temp.replace(output)
    return result,output.stat().st_mtime_ns


class Editor:
    def __init__(self, root, image, metadata, annotations, output):
        self.root=root;self.output=output;self.original=annotations;self.revision=0;self.photo=None
        self.dirty=False;self.current=None;self.selected=-1;self.vertex=None;self.pan_start=None;self.space=False;self.scale=1;self.offset=[0.,0.];self.undo_stack=[];self.redo_stack=[]
        root.title('BEV Studio | Map annotation');root.geometry('1440x960');root.minsize(1080,720);root.configure(bg='#f2f6f4')
        self.font_family=tkfont.nametofont('TkDefaultFont',root=root).actual('family')
        self.font_size=10;self.font_cache={};self.settings_path=Path.home()/'.bev_map_annotator/settings.json'
        try:
            prefs=json.loads(self.settings_path.read_text());family=prefs.get('font_family');size=int(prefs.get('font_size',10))
            if family in tkfont.families(root):self.font_family=family
            if 8<=size<=16:self.font_size=size
        except (OSError,ValueError,TypeError):pass
        root.option_add('*Font',self.ui_font(10))
        style=ttk.Style(root);style.theme_use('clam')
        style.configure('.',font=self.ui_font(10),background='#f2f6f4',foreground='#314b48')
        style.configure('TFrame',background='#f2f6f4');style.configure('Card.TFrame',background='#ffffff')
        style.configure('TLabel',background='#f2f6f4',foreground='#314b48')
        style.configure('Card.TLabel',background='#ffffff',foreground='#314b48')
        style.configure('Muted.TLabel',background='#ffffff',foreground='#849590',font=self.ui_font(9))
        style.configure('Section.TLabel',background='#ffffff',foreground='#8c9b96',font=self.ui_font(9))
        style.configure('TButton',background='#ffffff',foreground='#46615a',borderwidth=0,padding=(14,10),font=self.ui_font(10))
        style.map('TButton',background=[('active','#e8f3ee'),('pressed','#d9ebe3')])
        style.configure('Accent.TButton',background='#259780',foreground='#ffffff',padding=(18,11),font=self.ui_font(10))
        style.map('Accent.TButton',background=[('active','#1b826e'),('pressed','#176c5d')])
        style.configure('Soft.TButton',background='#e6f3ed',foreground='#28775f',padding=(14,10))
        style.map('Soft.TButton',background=[('active','#d4ebe0')])
        style.configure('Danger.TButton',background='#fff4f1',foreground='#b66a60',padding=(9,8))
        style.map('Danger.TButton',background=[('active','#ffe6df')])
        style.configure('TCombobox',fieldbackground='#f5f9f7',background='#f5f9f7',foreground='#36544a',bordercolor='#e3ece7',arrowcolor='#6f8f82',padding=8)
        style.map('TCombobox',fieldbackground=[('readonly','#f5f9f7')],selectbackground=[('readonly','#f5f9f7')],selectforeground=[('readonly','#36544a')])
        style.configure('TEntry',fieldbackground='#ffffff',bordercolor='#dce8e1',padding=7)
        style.configure('TCheckbutton',background='#ffffff',foreground='#6d847a',padding=5)
        style.map('TCheckbutton',background=[('active','#f0f8f3')])
        style.configure('Horizontal.TProgressbar',background='#4bac91',troughcolor='#e3efe8',borderwidth=0)
        header=ttk.Frame(root,padding=(26,18));header.pack(fill='x')
        brand=ttk.Frame(header);brand.pack(side='left')
        tk.Label(brand,text='B',font=self.ui_font(16),bg='#d9efe3',fg='#25866b',padx=13,pady=6).pack(side='left',padx=(0,12))
        brandtext=ttk.Frame(brand);brandtext.pack(side='left')
        ttk.Label(brandtext,text='BEV Studio',font=self.ui_font(16),foreground='#284b40').pack(anchor='w')
        ttk.Label(brandtext,text='A clearer space for precise map annotation',font=self.ui_font(9),foreground='#8b9d92').pack(anchor='w',pady=(3,0))
        ttk.Button(header,text='Save draft',style='Accent.TButton',command=self.save).pack(side='right',padx=(10,0))
        ttk.Button(header,text='Save as…',command=self.save_as).pack(side='right',padx=5)
        ttk.Button(header,text='Point clouds',style='Soft.TButton',command=self.pointcloud_dialog).pack(side='right',padx=5)
        ttk.Button(header,text='Open map',command=self.open_map).pack(side='right',padx=5)
        ttk.Button(header,text='Font…',command=self.font_dialog).pack(side='right',padx=5)
        body=ttk.Frame(root,padding=(24,0,24,12));body.pack(fill='both',expand=True)
        sidebar=ttk.Frame(body,style='Card.TFrame',padding=20,width=290);sidebar.pack(side='left',fill='y',padx=(0,16));sidebar.pack_propagate(False)
        self.category=tk.StringVar(value='drivable_area');self.feature=tk.StringVar();self.zoom_text=tk.StringVar();self.pan_mode=tk.BooleanVar();self.light_mode=tk.BooleanVar(value=False)
        self.document_text=tk.StringVar();self.coords_text=tk.StringVar();self.save_state=tk.StringVar(value='SAVED');self.count_text=tk.StringVar();self.feature_detail=tk.StringVar(value='Select a feature to edit its vertices.')
        ttk.Label(sidebar,text='MAP LAYERS',style='Section.TLabel').pack(anchor='w')
        ttk.Label(sidebar,text='Draw your map',style='Card.TLabel',font=self.ui_font(16)).pack(anchor='w',pady=(8,15))
        for label,key in [('Drivable area','drivable_area'),('Divider','divider'),('Pedestrian crossing','ped_crossing'),('Road boundary','boundary'),('Stop line','stopline')]:
            row=ttk.Frame(sidebar,style='Card.TFrame');row.pack(fill='x',pady=5)
            tk.Label(row,text='●',fg=COLORS[key],bg='#ffffff',font=self.ui_font(13)).pack(side='left',padx=(0,9))
            ttk.Label(row,text=label,style='Card.TLabel',font=self.ui_font(10)).pack(side='left')
        ttk.Label(sidebar,text='New feature category',style='Muted.TLabel').pack(anchor='w',pady=(20,7))
        ttk.Combobox(sidebar,textvariable=self.category,values=list(COLORS),state='readonly').pack(fill='x')
        ttk.Button(sidebar,text='＋  New feature',style='Accent.TButton',command=self.new).pack(fill='x',pady=(12,8))
        row=ttk.Frame(sidebar,style='Card.TFrame');row.pack(fill='x')
        ttk.Button(row,text='Finish drawing',style='Soft.TButton',command=self.finish).pack(side='left',fill='x',expand=True,padx=(0,5))
        ttk.Button(row,text='Cancel',command=self.cancel).pack(side='left')
        ttk.Separator(sidebar).pack(fill='x',pady=23)
        ttk.Label(sidebar,text='ANNOTATIONS',style='Section.TLabel').pack(anchor='w')
        ttk.Label(sidebar,textvariable=self.count_text,style='Card.TLabel',font=self.ui_font(14)).pack(anchor='w',pady=(8,12))
        self.chooser=ttk.Combobox(sidebar,textvariable=self.feature,state='readonly');self.chooser.pack(fill='x');self.chooser.bind('<<ComboboxSelected>>',self.select)
        ttk.Label(sidebar,textvariable=self.feature_detail,style='Muted.TLabel',wraplength=245).pack(anchor='w',pady=(10,15))
        row=ttk.Frame(sidebar,style='Card.TFrame');row.pack(fill='x')
        for label,fn in [('Undo',self.undo),('Redo',self.redo)]:ttk.Button(row,text=label,command=fn).pack(side='left',expand=True,fill='x',padx=(0,4))
        ttk.Button(sidebar,text='Delete selected feature',style='Danger.TButton',command=self.delete).pack(fill='x',pady=(8,0))
        ttk.Label(sidebar,text='QUICK GUIDE',style='Section.TLabel').pack(anchor='w',pady=(25,9))
        ttk.Label(sidebar,text='Click to place vertices.\nFinish to close the shape.\n\nDrag a vertex to adjust.\nDouble-click an edge to add.\nRight-click a vertex to remove.\n\nCtrl+S  Save    Ctrl+Z  Undo',style='Muted.TLabel',wraplength=245,justify='left').pack(anchor='w')
        main=ttk.Frame(body,style='Card.TFrame',padding=12);main.pack(side='left',fill='both',expand=True)
        viewbar=ttk.Frame(main,style='Card.TFrame');viewbar.pack(fill='x',pady=(0,10))
        ttk.Label(viewbar,text='Map canvas',style='Card.TLabel',font=self.ui_font(12)).pack(side='left',padx=6)
        ttk.Checkbutton(viewbar,text='Light map',variable=self.light_mode,command=self.refresh_display).pack(side='right',padx=5)
        ttk.Checkbutton(viewbar,text='Pan',variable=self.pan_mode).pack(side='right',padx=4)
        ttk.Label(viewbar,textvariable=self.zoom_text,style='Muted.TLabel',width=6,anchor='center').pack(side='right')
        for label,fn in [('Fit',self.fit),('−',lambda:self.zoom(1/1.5)),('+',lambda:self.zoom(1.5))]:ttk.Button(viewbar,text=label,command=fn,width=3).pack(side='right',padx=2)
        self.canvas=tk.Canvas(main,bg='#000000',highlightthickness=0);self.canvas.pack(fill='both',expand=True)
        footer=ttk.Frame(root,padding=(26,0,26,14));footer.pack(fill='x')
        self.status=tk.StringVar();ttk.Label(footer,textvariable=self.status,foreground='#72877a',font=self.ui_font(9),wraplength=1050).pack(side='left')
        tk.Label(footer,textvariable=self.save_state,font=self.ui_font(9),fg='#2b8c6b',bg='#e1f1e6',padx=12,pady=5).pack(side='right')
        self.canvas.bind('<Motion>',self.pointer_info);self.canvas.bind('<Configure>',self.resize);self.canvas.bind('<ButtonPress-1>',self.down);self.canvas.bind('<B1-Motion>',self.move);self.canvas.bind('<ButtonRelease-1>',self.up)
        self.canvas.bind('<ButtonPress-2>',self.pan_down);self.canvas.bind('<B2-Motion>',self.move);self.canvas.bind('<ButtonRelease-2>',self.up)
        self.canvas.bind('<Button-3>',self.remove_vertex);self.canvas.bind('<Double-Button-1>',self.insert_vertex)
        self.canvas.bind('<MouseWheel>',lambda e:self.zoom(1.2 if e.delta>0 else 1/1.2,(e.x,e.y)));self.canvas.bind('<Button-4>',lambda e:self.zoom(1.2,(e.x,e.y)));self.canvas.bind('<Button-5>',lambda e:self.zoom(1/1.2,(e.x,e.y)))
        root.bind('<KeyPress-space>',self.space_down);root.bind('<KeyRelease-space>',self.space_up);root.bind('<FocusOut>',self.focus_out)
        root.bind('<Escape>',lambda e:self.cancel());root.bind('<BackSpace>',lambda e:self.backspace());root.bind('<Control-s>',lambda e:self.save());root.bind('<Control-z>',lambda e:self.undo());root.bind('<Control-y>',lambda e:self.redo());root.protocol('WM_DELETE_WINDOW',self.close)
        self.load(image,metadata,annotations,output)
    def ui_font(self,base_size):
        if base_size not in self.font_cache:self.font_cache[base_size]=tkfont.Font(root=self.root,family=self.font_family,size=max(7,base_size+self.font_size-10),weight='normal')
        return self.font_cache[base_size]
    def apply_font(self,family,size):
        if family not in tkfont.families(self.root):raise ValueError('Choose an installed font family.')
        size=int(size)
        if not 8<=size<=16:raise ValueError('Font size must be between 8 and 16 points.')
        self.font_family=family;self.font_size=size
        for base,font in self.font_cache.items():font.configure(family=family,size=max(7,base+size-10),weight='normal')
        ttk.Style(self.root).configure('Treeview',rowheight=max(27,size*2+8))
    def font_dialog(self):
        original=(self.font_family,self.font_size);dialog=tk.Toplevel(self.root);dialog.title('Font preferences');dialog.transient(self.root);dialog.grab_set();dialog.resizable(False,False)
        content=ttk.Frame(dialog,padding=20);content.pack(fill='both',expand=True)
        family=tk.StringVar(value=self.font_family);size=tk.IntVar(value=self.font_size)
        ttk.Label(content,text='Interface font',font=self.ui_font(12)).grid(row=0,column=0,columnspan=2,sticky='w',pady=(0,15))
        ttk.Label(content,text='Family').grid(row=1,column=0,sticky='w',padx=(0,15))
        combo=ttk.Combobox(content,textvariable=family,values=sorted(set(tkfont.families(self.root)),key=str.casefold),state='readonly',width=36);combo.grid(row=1,column=1,pady=6)
        ttk.Label(content,text='Size (pt)').grid(row=2,column=0,sticky='w')
        ttk.Spinbox(content,textvariable=size,from_=8,to=16,width=8).grid(row=2,column=1,sticky='w',pady=6)
        sample=tkfont.Font(root=dialog,family=self.font_family,size=self.font_size,weight='normal')
        preview=tk.Label(content,text='BEV Studio  ·  Road annotation\n道路标注  ·  0123456789',font=sample,bg='#ffffff',fg='#334155',padx=16,pady=18);preview.grid(row=3,column=0,columnspan=2,sticky='ew',pady=15)
        hint=ttk.Label(content,text='Select a family to preview. Save keeps it for the next launch.',wraplength=390);hint.grid(row=4,column=0,columnspan=2,sticky='w')
        def update(*_):
            try:
                value=int(size.get())
                if 8<=value<=16:sample.configure(family=family.get(),size=value);self.apply_font(family.get(),value)
            except (tk.TclError,ValueError):pass
        family.trace_add('write',update);size.trace_add('write',update)
        def cancel():self.apply_font(*original);dialog.destroy()
        def save():
            try:
                self.apply_font(family.get(),size.get());prefs={}
                if self.settings_path.exists():
                    try:prefs=json.loads(self.settings_path.read_text())
                    except (ValueError,TypeError):prefs={}
                prefs.update(font_family=self.font_family,font_size=self.font_size);self.settings_path.parent.mkdir(parents=True,exist_ok=True);temp=self.settings_path.with_suffix('.tmp');temp.write_text(json.dumps(prefs,indent=2)+'\n');temp.replace(self.settings_path)
            except (ValueError,OSError,tk.TclError) as exc:messagebox.showerror('Font preferences',str(exc),parent=dialog);return
            dialog.destroy();self.say(f'Interface font: {self.font_family}, {self.font_size} pt. Preference saved.')
        buttons=ttk.Frame(content);buttons.grid(row=5,column=0,columnspan=2,sticky='e',pady=(18,0));ttk.Button(buttons,text='Cancel',command=cancel).pack(side='left',padx=5);ttk.Button(buttons,text='Save preference',style='Accent.TButton',command=save).pack(side='left');dialog.protocol('WM_DELETE_WINDOW',cancel)
    def say(self,text):self.status.set(text)
    def load(self,image,metadata,annotations,output):
        picture=Image.open(image).convert('RGB');meta=json.loads(metadata.read_text());meta.setdefault('image_size',list(picture.size))
        if meta['image_size']!=list(picture.size) or not float(meta['resolution_m'])>0 or len(meta['minimum_world_xy'])!=2:raise ValueError('Invalid map dimensions, origin or resolution')
        data=json.loads(output.read_text()) if output.exists() else json.loads(annotations.read_text()) if annotations.exists() else {'type':'FeatureCollection','features':[]}
        validate(data);self.document_text.set(f'{image.name}   ·   {picture.width} × {picture.height} px');self.image=picture;self.display_image=self.make_display_image();self.meta=meta;self.data=data;self.original=annotations.resolve();self.output=output.resolve();self.revision=output.stat().st_mtime_ns if output.exists() else 0;self.dirty=False;self.current=None;self.selected=-1;self.undo_stack=[];self.redo_stack=[];self.refresh_choices();self.root.after_idle(self.fit);self.say(f'Loaded {len(data["features"])} features. Save to: {self.output}')
    def screen(self,p):
        q=world_to_pixel(p,self.meta);return [q[0]*self.scale+self.offset[0],q[1]*self.scale+self.offset[1]]
    def world(self,x,y):return pixel_to_world([(x-self.offset[0])/self.scale,(y-self.offset[1])/self.scale],self.meta)
    def rings(self,g):return g['coordinates'] if g['type']=='Polygon' else [g['coordinates']]
    def make_display_image(self):
        if not self.light_mode.get():
            image=self.image.copy()
            # Render the known no-return background as black; keep source pixels intact.
            import numpy as np
            pixels=np.array(image);pixels[(pixels==[14,22,34]).all(axis=2)]=0
            return Image.fromarray(pixels)
        # View-only tone mapping; source pixels, world geometry and exports remain unchanged.
        return ImageOps.colorize(ImageOps.invert(ImageOps.grayscale(self.image)),black='#475569',white='#fcfdff')
    def refresh_display(self):
        if not hasattr(self,'image'):return
        self.display_image=self.make_display_image();self.redraw()
    def redraw(self):
        if not hasattr(self,'image'):return
        w=max(1,self.canvas.winfo_width());h=max(1,self.canvas.winfo_height());self.canvas.delete('all')
        # Resample only the viewport, never allocate a full 20x map image.
        im=self.display_image.transform((w,h),Image.Transform.AFFINE,(1/self.scale,0,-self.offset[0]/self.scale,0,1/self.scale,-self.offset[1]/self.scale),Image.Resampling.BILINEAR,fillcolor='#eef1f5' if self.light_mode.get() else '#000000');self.photo=ImageTk.PhotoImage(im);self.canvas.create_image(0,0,image=self.photo,anchor='nw')
        for i,f in enumerate(self.data['features']+([self.current] if self.current else [])):
            for ring in self.rings(f['geometry']):
                coords=[v for p in ring for v in self.screen(p)]
                if len(coords)>=4:self.canvas.create_line(*coords,fill=COLORS[f['properties']['category']],width=2)
                if i==self.selected or f is self.current:
                    for p in ring:
                        x,y=self.screen(p);self.canvas.create_oval(x-4,y-4,x+4,y+4,fill='#ffffff',outline='#269d80',width=2)
        fit=min(w/self.image.width,h/self.image.height);self.zoom_text.set(f'{self.scale/fit*100:.0f}%');self.canvas.configure(cursor='fleur' if self.pan_mode.get() or self.space else 'crosshair')
    def fit(self):
        if not hasattr(self,'image'):return
        w=max(1,self.canvas.winfo_width());h=max(1,self.canvas.winfo_height());self.scale=min(w/self.image.width,h/self.image.height);self.offset=[(w-self.image.width*self.scale)/2,(h-self.image.height*self.scale)/2];self.redraw()
    def resize(self,event):
        if self.photo is None:self.fit()
        else:self.redraw()
    def zoom(self,factor,p=None):
        if not hasattr(self,'image'):return
        p=p or (self.canvas.winfo_width()/2,self.canvas.winfo_height()/2);fit=min(self.canvas.winfo_width()/self.image.width,self.canvas.winfo_height()/self.image.height);next_scale=max(fit*.5,min(fit*20,self.scale*factor));ratio=next_scale/self.scale;self.offset=[p[0]-(p[0]-self.offset[0])*ratio,p[1]-(p[1]-self.offset[1])*ratio];self.scale=next_scale;self.redraw()
    def checkpoint(self):self.undo_stack.append(copy.deepcopy(self.data));self.undo_stack=self.undo_stack[-100:];self.redo_stack=[]
    def changed(self):self.dirty=True;self.refresh_choices();self.redraw();self.say('Unsaved changes. Click Save to persist.')
    def refresh_choices(self):
        choices=['None selected']+[f'{i} · {f["properties"]["category"]}' for i,f in enumerate(self.data['features'])];self.chooser['values']=choices;self.chooser.current(self.selected+1)
        self.count_text.set(f'{len(self.data["features"])} map features');self.save_state.set('DRAWING' if self.current else 'UNSAVED' if self.dirty else 'SAVED')
        feature=self.data['features'][self.selected] if self.selected>=0 else None
        self.feature_detail.set((feature['geometry']['type']+' · '+str(sum(len(r) for r in self.rings(feature['geometry'])))+' vertices') if feature else 'Select a feature to edit its vertices.')
    def pointer_info(self,event):
        if hasattr(self,'meta'):
            x,y=self.world(event.x,event.y);self.coords_text.set(f'X {x:.2f} m   Y {y:.2f} m')
    def tree_select(self,event=None):
        selected=self.feature_tree.selection()
        if not selected:return
        index=int(selected[0])
        if index==self.selected:return
        if self.current:self.say('Finish or cancel the current drawing first.');return
        self.chooser.current(index+1);self.select()
    def select(self,event=None):
        if self.current:self.say('Finish or cancel drawing first.');self.refresh_choices();return
        self.selected=self.chooser.current()-1;self.refresh_choices();self.redraw()
    def new(self):
        if self.current:self.say('Finish or cancel the current drawing.');return
        category=self.category.get();polygon=category in ('drivable_area','ped_crossing');self.current={'type':'Feature','properties':{'category':category,'review_status':'draft'},'geometry':{'type':'Polygon' if polygon else 'LineString','coordinates':[[]] if polygon else []}};self.selected=-1;self.refresh_choices();self.say('Click vertices in boundary order, then Finish.');self.redraw()
    def finish(self):
        if not self.current:return
        feature=copy.deepcopy(self.current);g=feature['geometry'];p=self.rings(g)[0]
        if len(p)<(3 if g['type']=='Polygon' else 2):self.say('Not enough vertices.');return
        if g['type']=='Polygon':p.append(p[0].copy())
        try:validate({'type':'FeatureCollection','features':[feature]})
        except ValueError as exc:self.say(f'{exc}. Use Backspace to revise drawing.');return
        self.checkpoint();self.data['features'].append(feature);self.current=None;self.selected=len(self.data['features'])-1;self.changed()
    def cancel(self):self.current=None;self.refresh_choices();self.redraw();self.say('Drawing cancelled. Completed features are unchanged.')
    def backspace(self):
        if self.current:
            p=self.rings(self.current['geometry'])[0]
            if p:p.pop();self.redraw()
    def delete(self):
        if self.current:self.say('Finish or cancel drawing first.');return
        if self.selected<0:return
        self.checkpoint();self.data['features'].pop(self.selected);self.selected=-1;self.changed()
    def undo(self):
        if self.current:self.backspace();return
        if not self.undo_stack:return
        self.redo_stack.append(copy.deepcopy(self.data));self.data=self.undo_stack.pop();self.selected=-1;self.changed()
    def redo(self):
        if self.current or not self.redo_stack:return
        self.undo_stack.append(copy.deepcopy(self.data));self.data=self.redo_stack.pop();self.selected=-1;self.changed()
    def nearest(self,x,y):
        if self.selected<0:return None
        best=12;hit=None
        for ri,ring in enumerate(self.rings(self.data['features'][self.selected]['geometry'])):
            for vi,p in enumerate(ring):
                q=self.screen(p);d=((q[0]-x)**2+(q[1]-y)**2)**.5
                if d<best:best=d;hit=(ri,vi)
        return hit
    def down(self,e):
        self.canvas.focus_set()
        if self.space or self.pan_mode.get():self.pan_down(e);return
        if self.current:self.rings(self.current['geometry'])[0].append(self.world(e.x,e.y));self.redraw();return
        self.vertex=self.nearest(e.x,e.y)
        if self.vertex:self.checkpoint()
    def pan_down(self,e):self.pan_start=(e.x,e.y,self.offset.copy())
    def move(self,e):
        if self.pan_start:
            x,y,o=self.pan_start;self.offset=[o[0]+e.x-x,o[1]+e.y-y];self.redraw();return
        if not self.vertex:return
        ri,i=self.vertex;g=self.data['features'][self.selected]['geometry'];ring=self.rings(g)[ri];p=self.world(e.x,e.y);ring[i]=p
        if g['type']=='Polygon' and i in (0,len(ring)-1):ring[0]=p;ring[-1]=p.copy()
        self.changed()
    def up(self,e):self.pan_start=None;self.vertex=None
    def insert_vertex(self,e):
        if self.current or self.selected<0 or self.pan_mode.get() or self.space:return
        best=14;hit=None
        for ri,ring in enumerate(self.rings(self.data['features'][self.selected]['geometry'])):
            for i in range(len(ring)-1):
                a=self.screen(ring[i]);b=self.screen(ring[i+1]);dx=b[0]-a[0];dy=b[1]-a[1];t=max(0,min(1,((e.x-a[0])*dx+(e.y-a[1])*dy)/(dx*dx+dy*dy or 1)));d=((e.x-a[0]-t*dx)**2+(e.y-a[1]-t*dy)**2)**.5
                if d<best:best=d;hit=(ri,i+1)
        if hit:self.checkpoint();self.rings(self.data['features'][self.selected]['geometry'])[hit[0]].insert(hit[1],self.world(e.x,e.y));self.changed()
    def remove_vertex(self,e):
        if self.current:self.backspace();return
        hit=self.nearest(e.x,e.y)
        if not hit:return
        g=self.data['features'][self.selected]['geometry'];ring=self.rings(g)[hit[0]];i=hit[1]
        if len(ring)<=(4 if g['type']=='Polygon' else 2):self.say('Cannot remove below minimum vertex count.');return
        self.checkpoint()
        if g['type']=='Polygon':
            ring.pop()
            if i==len(ring):i=0
            ring.pop(i);ring.append(ring[0].copy())
        else:ring.pop(i)
        self.changed()
    def save(self):
        if self.current:self.say('Finish or cancel drawing before saving.');return False
        try:
            self.data['coordinate_frame']=self.meta.get('coordinate_frame','local_world_meters_not_WGS84');self.data,self.revision=save_annotation(self.data,self.output,self.revision);self.dirty=False;self.refresh_choices();self.say(f'Saved {len(self.data["features"])} features: {self.output}');return True
        except (ValueError,OSError) as exc:messagebox.showerror('Save failed',str(exc));return False
    def save_as(self):
        name=filedialog.asksaveasfilename(title='Save annotation as',defaultextension='.geojson',filetypes=[('GeoJSON','*.geojson')])
        if not name:return
        p=Path(name).resolve()
        if p==self.original:messagebox.showerror('Preserve original','Choose a file different from the input annotation.');return
        old,revision=self.output,self.revision;self.output=p;self.revision=p.stat().st_mtime_ns if p.exists() else 0
        if not self.save():self.output=old;self.revision=revision
    def can_leave(self):
        if self.current:
            if not messagebox.askyesno('Unfinished drawing','Discard unfinished drawing?'):return False
        if self.dirty:
            choice=messagebox.askyesnocancel('Unsaved changes','Save changes before continuing?')
            if choice is None:return False
            if choice:
                self.current=None
                if not self.save():return False
        return True
    def open_map(self):
        if not self.can_leave():return
        image=filedialog.askopenfilename(title='Select BEV image',filetypes=[('Images','*.png *.jpg *.jpeg *.tif *.tiff')])
        if not image:return
        metadata=filedialog.askopenfilename(title='Select metadata.json',filetypes=[('JSON','*.json')])
        if not metadata:return
        annotation=filedialog.askopenfilename(title='Optional initial GeoJSON (Cancel = empty)',filetypes=[('GeoJSON','*.geojson')]);annotations=Path(annotation) if annotation else Path(image).with_name('__empty_initial__.geojson')
        output=filedialog.asksaveasfilename(title='Choose output GeoJSON',defaultextension='.geojson')
        if not output:return
        if annotations.resolve()==Path(output).resolve():messagebox.showerror('Preserve original','Input/output must differ.');return
        try:self.load(Path(image),Path(metadata),annotations,Path(output))
        except Exception as exc:messagebox.showerror('Open failed',str(exc))
    def pointcloud_dialog(self):
        if not self.can_leave():return
        dialog=tk.Toplevel(self.root);dialog.title('Build BEV from point-cloud sequence');dialog.transient(self.root);dialog.grab_set();fields={}
        specs=[('cloud_dir','Point-cloud directory',''),('pattern','File pattern','**/*.pcd'),('start','First frame (blank = first)',''),('end','Last frame (blank = last)',''),('stride','Map sampling stride','10'),('resolution','Resolution (m/pixel)','0.15'),('poses','Pose override (default: KISS-ICP)',''),('output','Output directory (blank = auto)','')]
        for row,(key,label,default) in enumerate(specs):
            ttk.Label(dialog,text=label).grid(row=row,column=0,padx=10,pady=5,sticky='w');var=tk.StringVar(value=default);fields[key]=var;ttk.Entry(dialog,textvariable=var,width=65).grid(row=row,column=1,padx=5,pady=5)
            if key in ('cloud_dir','output','poses'):
                def browse(k=key):
                    path=filedialog.askopenfilename(parent=dialog,title='Choose poses.json',filetypes=[('JSON','*.json')]) if k=='poses' else filedialog.askdirectory(parent=dialog,title='Choose '+k)
                    if path:fields[k].set(path)
                ttk.Button(dialog,text='Browse',command=browse).grid(row=row,column=2,padx=8)
        ttk.Label(dialog,text='Default **/*.pcd scans all subfolders; **/*.bin scans KITTI BIN files.\nDefault: KISS-ICP aligns all selected frames; pose file is an optional override.').grid(row=8,column=0,columnspan=3,padx=10,pady=10)
        def begin():
            try:
                options={k:v.get().strip() for k,v in fields.items()}
                if not options['cloud_dir']:raise ValueError('Input directory is required')
                options['stride']=int(options['stride']);options['resolution']=float(options['resolution'])
                if options['stride']<1 or options['resolution']<=0:raise ValueError('Positive stride/resolution required')
            except ValueError as exc:messagebox.showerror('Invalid settings',str(exc),parent=dialog);return
            dialog.destroy();self.start_sequence_build(options)
        ttk.Button(dialog,text='Build map and annotate',command=begin).grid(row=9,column=1,padx=10,pady=12)
    def start_sequence_build(self,options):
        events=queue.Queue();cancel=threading.Event();popup=tk.Toplevel(self.root);popup.title('Building BEV');popup.transient(self.root);popup.grab_set();text=tk.StringVar(value='Loading provided poses…' if options.get('poses') else 'Preparing KISS-ICP automatic alignment…');ttk.Label(popup,textvariable=text,padding=16,width=70).pack();bar=ttk.Progressbar(popup,length=500);bar.pack(padx=16,pady=8);ttk.Button(popup,text='Cancel',command=lambda:(cancel.set(),text.set('Cancelling after current scan…'))).pack(pady=12);popup.protocol('WM_DELETE_WINDOW',lambda:cancel.set())
        def worker():
            try:
                from build_bev import build
                result=build(options['cloud_dir'],options.get('output') or None,options.get('pattern','**/*.pcd'),options.get('start') or None,options.get('end') or None,int(options.get('stride',10)),float(options.get('resolution',.15)),options.get('poses') or None,progress=lambda s,i,n:events.put(('progress',(s,i,n))),cancelled=cancel.is_set);events.put(('done',result))
            except Exception as exc:events.put(('error',str(exc)))
        threading.Thread(target=worker,daemon=True).start()
        def poll():
            try:
                while True:
                    kind,value=events.get_nowait()
                    if kind=='progress':text.set(value[0]);bar.configure(maximum=value[2],value=value[1])
                    else:
                        popup.destroy()
                        if kind=='error':messagebox.showerror('BEV build stopped',value);return
                        folder=value
                        try:self.load(folder/'ground_reflectivity.png',folder/'metadata.json',folder/'annotations.geojson',folder/'reviewed_annotations.geojson')
                        except Exception as exc:messagebox.showerror('Map load failed',str(exc))
                        return
            except queue.Empty:pass
            self.root.after(100,poll)
        self.root.after(100,poll)
    def space_down(self,e):
        if isinstance(e.widget,(tk.Entry,ttk.Entry,ttk.Combobox)):return
        self.space=True;self.canvas.configure(cursor='fleur');return 'break'
    def space_up(self,e):self.space=False;self.redraw()
    def focus_out(self,e):
        if e.widget is self.root:self.space=False;self.pan_start=None;self.vertex=None
    def close(self):
        if self.can_leave():self.root.destroy()


def main():
    base=Path(__file__).resolve().parent;p=argparse.ArgumentParser(description=__doc__);p.add_argument('--image',type=Path,default=base/'example/ground_reflectivity.png');p.add_argument('--metadata',type=Path,default=base/'example/metadata.json');p.add_argument('--annotations',type=Path,default=base/'example/annotations.geojson');p.add_argument('--output',type=Path,default=base/'saved/reviewed_annotations.geojson');p.add_argument('--cloud-dir',type=Path);p.add_argument('--poses',type=Path,help='Optional pose override; default uses KISS-ICP automatically');p.add_argument('--pattern',default='**/*.pcd');p.add_argument('--start');p.add_argument('--end');p.add_argument('--stride',type=int,default=10);p.add_argument('--resolution',type=float,default=.15);p.add_argument('--map-output',type=Path);a=p.parse_args()
    if a.output.resolve()==a.annotations.resolve():p.error('Input/output annotations must differ')
    root=tk.Tk()
    try:
        editor=Editor(root,a.image,a.metadata,a.annotations,a.output)
        if a.cloud_dir:
            options={"cloud_dir":str(a.cloud_dir),"output":str(a.map_output) if a.map_output else "","poses":str(a.poses) if a.poses else "","pattern":a.pattern,"start":a.start,"end":a.end,"stride":a.stride,"resolution":a.resolution}
            root.after(100,lambda:editor.start_sequence_build(options))
    except Exception as exc:root.destroy();raise SystemExit(str(exc))
    root.mainloop()

if __name__=='__main__':main()
