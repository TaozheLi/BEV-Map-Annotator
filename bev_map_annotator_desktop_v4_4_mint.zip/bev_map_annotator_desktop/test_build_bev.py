import json,tempfile,unittest
from pathlib import Path
import numpy as np
from PIL import Image
from build_bev import collect_paths,build,load_poses,default_output

class SequenceTests(unittest.TestCase):
 def test_default_output_is_unique_and_tool_relative(self):
  a=default_output('/tmp/capture');b=default_output('/tmp/capture')
  self.assertNotEqual(a,b);self.assertEqual(a.parent,Path(__file__).resolve().parent/'generated_maps');self.assertTrue(a.name.startswith('capture_'));self.assertFalse(a.exists())
 def test_natural_order_and_inclusive_range(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)
   for name in ['10','2','1']:(p/f'{name}.pcd').touch()
   self.assertEqual([x[0] for x in collect_paths(p,'*.pcd')],['1','2','10'])
   self.assertEqual([x[0] for x in collect_paths(p,'*.pcd','2','10')],['2','10'])
 def test_recursive_directories_duplicate_names_and_range(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)
   for name in ['02/1.pcd','01/10.pcd','01/2.pcd','01/1.pcd']:
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.touch()
   frames=collect_paths(root)
   self.assertEqual([p.relative_to(root).as_posix() for _,p in frames],['01/1.pcd','01/2.pcd','01/10.pcd','02/1.pcd'])
   self.assertEqual(frames[0][0],'01/1');self.assertEqual(frames[-1][0],'02/1')
   self.assertEqual(len(collect_paths(root,start='01/2.pcd',end='02/1.pcd')),3)
   with self.assertRaisesRegex(ValueError,'Ambiguous'):collect_paths(root,start='1')
 def test_build_from_binary_sequence_and_provided_poses(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);cloud=p/'cloud';cloud.mkdir();x,y=np.meshgrid(np.linspace(-8,8,40),np.linspace(-8,8,40));xyz=np.column_stack([x.ravel(),y.ravel(),np.full(x.size,-1.75),np.linspace(0,255,x.size)]).astype('<f4')
   rows=[]
   for i in range(2):
    name=f'{i+1:06d}';xyz.tofile(cloud/f'{name}.bin');T=np.eye(4);T[0,3]=i*2;rows.append({'frame':name,'T_world_from_lidar':T.tolist()})
   poses=p/'poses.json';poses.write_text(json.dumps(rows));out=build(cloud,p/'map','*.bin',stride=1,poses_path=poses)
   m=json.loads((out/'metadata.json').read_text());self.assertEqual(m['source_frames'],['000001','000002']);self.assertEqual(m['alignment'],'provided poses');
   with Image.open(out/'ground_reflectivity.png') as image:self.assertEqual(list(image.size),m['image_size'])
   with np.load(out/'ground_map.npz') as raster:self.assertGreater(raster['count'].sum(),100)
   with self.assertRaises(ValueError):build(cloud,out,'*.bin',poses_path=poses)
 def test_invalid_pose_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'poses.json';T=np.eye(4);T[0,0]=2;p.write_text(json.dumps([{'frame':'1','T_world_from_lidar':T.tolist()}]))
   with self.assertRaises(ValueError):load_poses(p)

if __name__=='__main__':unittest.main()
