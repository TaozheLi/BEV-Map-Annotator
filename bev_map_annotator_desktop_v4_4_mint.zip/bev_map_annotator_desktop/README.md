# BEV Map Annotator — 本地桌面版

**原生 Tkinter 桌面窗口，无网页、无浏览器、无 HTTP 服务、无端口。** 可以独立复制到其他电脑运行，不依赖 OccLabelGeneration、GPU、PyTorch、模型权重、相机或点云。

## 环境

已验证 CPython **3.10.21**、Tk **8.6**，依赖版本见 `requirements.txt`。Python 版本记录在 `.python-version`；Tkinter 属于 Python/系统组件，无法通过 pip requirements 安装，因此单独说明。

Linux 安装与启动：
```bash
cd bev_map_annotator_desktop
python3.10 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

Windows：
```bat
cd bev_map_annotator_desktop
py -3.10 -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

macOS：使用带 Tk 支持的 Python 3.10 安装包，再按 Linux 的虚拟环境命令启动。

检查 Tkinter：`python -m tkinter` 应弹出测试窗口。Ubuntu/Debian 系统 Python 若缺少 Tkinter，需要对应版本的 `python3-tk` 或 `python3.10-tk` 系统包；Conda 环境安装 `tk`。应用需要图形桌面显示环境，SSH 纯终端不能直接弹出窗口。

## 功能

- drivable_area：可行驶区域 Polygon。
- divider：分隔标线 LineString。
- ped_crossing：斑马线整体 Polygon。
- boundary：道路边界 LineString，额外保留。
- 图片缩放、平移，顶点拖动、增删，保存/另存为、自动历史备份、撤销/重做。
- 保存时检查交叉多边形、无效几何；如果另一个编辑器改了输出文件，会拒绝覆盖。
- 原始示例标注保持不变，保存到独立输出文件。

## 操作

1. 选择类别 → New → 在图片上沿边界依次点击 → Finish。多边形自动闭合，四个角应顺时针或逆时针依次点击。
2. 用上方要素下拉框选择已有要素，拖动橙色顶点修改。
3. 双击边线添加顶点；右键顶点删除。Delete 删除整个选中要素。
4. 滚轮或＋/－缩放；Fit map 显示全图。按住空格或鼠标中键拖动平移，或勾选 Pan mode 后左键拖动。
5. Cancel / Esc 取消未完成绘制；Backspace 移除绘制中的最后一个点。
6. Save / Ctrl+S 保存；Save As 另存。Ctrl+Z / Ctrl+Y 撤销、重做。
7. Open map 依次选择图片、坐标 JSON、可选初始 GeoJSON 和输出文件。关闭窗口/打开其他地图前，会提示处理未保存修改。

## 自定义地图

```bash
python app.py \
 --image /path/to/map.png \
 --metadata /path/to/metadata.json \
 --annotations /path/to/initial.geojson \
 --output /path/to/saved/reviewed_annotations.geojson
```

`--annotations` 指向不存在的文件时从空标注开始。输出文件与初始标注文件必须不同；已有输出文件会优先加载。

最小 metadata.json：
```json
{
  "coordinate_frame": "local_world_meters_not_WGS84",
  "resolution_m": 0.15,
  "minimum_world_xy": [-300.0, -120.0],
  "image_size": [2527, 2117]
}
```

`image_size` 是真实图片的 `[宽, 高]`；`minimum_world_xy` 是左下角外边界坐标（米）。向右为 +X，向上为 +Y。像素中心到地图坐标的公式为：

```text
x = xmin + (u + 0.5) * resolution_m
y = ymin + (height - 1 - v + 0.5) * resolution_m
```

仅支持轴对齐、等比例地图；输出为局部米制坐标，不是经纬度。输出保留 `properties.category`，可直接作为原项目的 `reviewed_annotations.geojson` 使用。

## 文件

```text
app.py                  桌面窗口、编辑和保存
geometry.py             GeoJSON 校验
requirements.txt        Pillow / Shapely / NumPy 测试版本
.python-version         Python 3.10.21
example/                当前 BEV 图片及85个已保存标注
saved/                  首次保存后生成
  reviewed_annotations.geojson
  backups/              每次覆盖前保留旧版本
```

运行测试：`python -m unittest test_app.py -v`。无图形显示环境时，桌面集成测试会标记为跳过，其余数据测试仍运行。

English: a standalone native Tkinter desktop application. Install the pinned dependencies under Python 3.10.21 with Tk 8.6, then run `python app.py`. No browser/server/GPU is used. Annotations are saved as compatible local-metric GeoJSON; input files are preserved and previous saves are backed up.

## 连续点云直接作为输入（v2）

窗口顶部新增 **Point clouds** 按钮。选择点云根目录、文件匹配模式、起止帧、建图采样间隔、分辨率以及新输出目录，点 Build map and annotate。工具自动读取、对齐、提取地面、生成BEV，再直接载入标注画布；生成时弹出进度窗口，可取消。

支持两种目录布局：
```text
capture/000001/lidar.pcd ... capture/002808/lidar.pcd  # pattern: */lidar.pcd
clouds/000001.pcd ... clouds/002808.pcd               # pattern: *.pcd
clouds/000001.bin ... clouds/002808.bin               # pattern: *.bin
```
PCD 支持 ASCII 和未压缩 binary；BIN 为 KITTI float32 XYZI 四列格式。frame ID 取 lidar.pcd 的父目录名，否则取文件名去扩展名。按自然顺序排序；起止帧是含首尾的文件ID，不是数组索引。

**位姿可以不选**：自动用 CPU KISS-ICP 对选定范围的每帧做配准，首帧成为局部世界原点。有已有 `poses.json` 时直接读取，保持旧地图世界坐标；这也能减少重复运算。stride只控制地面建图采样，自动定位仍处理所有选中连续帧。

例如，沿用当前采集的位姿：
```bash
python app.py \
 --cloud-dir /home/mila/datasets/20261012_142203 \
 --pattern '*/lidar.pcd' --start 000001 --end 002808 \
 --stride 10 --resolution 0.15 \
 --poses /path/to/poses.json \
 --map-output /path/to/new_bev_map
```

只指定点云目录，自动配准：
```bash
python app.py --cloud-dir /path/to/capture --map-output /path/to/new_bev_map
```

点云建图需要 `requirements.txt` 中的 `kiss-icp==1.3.0`，不需要 Open3D 或 GPU。只用已有位姿时也无需调用 KISS-ICP。位姿 JSON 格式：
```json
[
  {"frame": "000001", "T_world_from_lidar": [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]}
]
```
必须覆盖选定帧，矩阵为原始 LiDAR 到世界坐标的4×4刚体变换。原始输入要求米制、Z轴向上、传感器下方约1.75m为地面。当前地面提取沿用项目参数（范围40m、候选高度-3.5至-0.6m、近水平RANSAC），其他安装高度或坐标轴需要先适配；工具不假定未知点云已对齐，也不直接叠加移动传感器的原始帧。

如同目录有匹配的 `lidar_timing.npz`（column_timestamp_ns、measurement_id）和 PCD column 字段，自动ICP会使用列时间戳去畸变；否则无逐点时间矫正。沿用既有位姿时，底图构建采用与原项目一致的静态逐帧坐标变换。检查轨迹漂移/重影后再正式标注。

新地图目录包含 ground_reflectivity.png、ground_map.npz、metadata.json、poses.json、空白 annotations.geojson；人工保存写入 reviewed_annotations.geojson。自动生成的是几何地面底图，不是自动道路语义标注。生成过程不覆盖已有非空输出目录。

也可仅生成底图：
```bash
python build_bev.py --cloud-dir /path/to/capture --output /path/to/new_bev_map
```

### 多层目录（v2.1）

现在默认匹配 **`**/*.pcd`**，递归读取根目录及其所有子目录：
```text
root/
  01/000001.pcd
  01/000002.pcd
  02/000001.pcd
  02/subfolder/000002.pcd
```
按子目录和文件名自然排序（01 → 02，2 → 10）。路径中同名文件不会覆盖；frame ID 重复时改用相对路径，例如 `01/000001`、`02/000001`。起止帧可以填相对路径（含或不含 `.pcd`）；只填文件名但出现多个匹配时会提示歧义，要求补全路径。沿用位姿文件时，重复文件名对应的 `frame` 也必须采用这些相对路径ID。

```bash
python app.py --cloud-dir /path/to/root \
 --start 01/000001.pcd --end 02/000100.pcd \
 --map-output /path/to/new_bev_map
```

只读某个子目录时，直接选该子目录为输入目录，或将 File pattern 改为 `01/*.pcd`。BIN 使用 `**/*.bin`。自动配准假定所选目录排序后是一段连续采集序列；如果01与02为不连续的不同采集，应分别生成地图，或提供同一世界坐标系下的正确位姿。

### 默认输出（v2.2）

点云建图的输出目录现在可不填，命令行也可省略 `--map-output`（app.py）或 `--output`（build_bev.py）。自动创建在**工具自身目录**下：
```text
generated_maps/<输入目录名>_<年月日_时分秒_微秒>_<唯一后缀>/
```

每次新建独立目录，不覆盖之前的地图。生成完成后状态栏显示实际保存位置，人工标注保存在该目录的 `reviewed_annotations.geojson`。

```bash
python app.py --cloud-dir /path/to/root
# 仅生成图片：
python build_bev.py --cloud-dir /path/to/root
```

GUI 的 Output directory 留空使用上述默认值；手动填写则使用指定的新空目录。已有图片标注模式的 `--output` 仍表示人工 GeoJSON 输出文件，与点云建图目录参数 `--map-output` 不同。

### 默认配准（v2.3）

默认 **KISS-ICP 自动配准**，无需位姿文件。仅主动传入 `--poses` 或在界面选择位姿文件时，才覆盖默认算法并沿用已有位姿。运行 `python app.py --cloud-dir /path/to/root` 即可；递归读取与默认输出目录均已启用。

## 清新界面（v3）

桌面 UI 更新为暖白＋薄荷绿：顶部文件操作区，左侧图层颜色、绘制和要素编辑面板，右侧大地图画布，底部保存状态。标注类别和工具仍使用英文。

默认启用 **Light map**，将深色反射强度底图仅在显示时映射为浅色背景、深色细节；取消勾选即恢复原图显示。原始图像文件、反射强度数据、像素-世界坐标变换及导出结果均不改变。

仍默认 KISS-ICP、递归点云输入和自动 output，安装和启动命令不变。

### 字体（v3.1）

改用系统默认 UI 字体，统一正常字重，取消粗体标题。清新配色和全部功能保留。

### 停止线（v3.2）

新增类别 `stopline`（Stop line），使用珊瑚橙色显示，几何类型为 LineString。选择 stopline → New feature → 沿停止线点击至少两个点 → Finish drawing → Save draft。输出 properties.category 为 stopline；不是闭合多边形。原 Occ/UniAD 训练转换器尚未添加独立 stopline 类，不能直接将含此新类的标注交给旧转换器而不适配。

## 专业工作区（v4）

采用中性灰白与蓝色操作强调，保留系统正常字重字体。顶部为紧凑文件工具区；左侧是绘制工具与可滚动要素表（ID / Category / Pts），右侧为主画布。表格行颜色对应标注类别，点击行即可选中编辑。底部实时显示光标世界XY坐标（米）及保存状态。增加 File / Edit / View 菜单，未开始绘制时 Finish/Cancel 自动禁用。未添加旋转，现有缩放、平移、stopline、默认KISS-ICP和自动输出目录继续保留。

## 字体选择（v4.1）

点击顶部 **Font…** 或 View → Font，选择本机已安装字体及8–16pt字号。选择后实时预览整个界面，保持正常字重。Cancel 恢复打开对话框之前的字体；Save preference 保存到用户目录 `.bev_map_annotator/settings.json`，下次自动恢复。字体仅影响显示，不改变地图图片、标注坐标或导出文件。不同电脑字体列表可能不同，未安装的已保存字体会回退到系统默认。

### 默认黑色地图背景（v4.2）

默认关闭 Light map，地图画布和示例底图的无回波背景显示为黑色；界面面板保留专业浅色风格。Light map 仍可手动启用。仅改变显示，不改写源图像、标注或导出坐标。

## 外观回退（v4.3）

恢复v2点云桌面版的深色工具栏与顶部要素下拉框布局，取消专业版侧边表格。功能继续保留 stopline、顶部Font字体选择、默认黑色画布、递归点云目录、默认KISS-ICP与自动输出。字体对话框从顶部 Font… 打开。

## 外观纠正（v4.4 mint）

恢复用户指定的v3薄荷绿＋奶白清新界面：左侧绘制和要素编辑面板，右侧大地图画布。地图默认仍为黑色，字体选择、stopline、递归点云读取、默认KISS-ICP与自动输出目录均保留。不使用最早的深色工具栏外观。
