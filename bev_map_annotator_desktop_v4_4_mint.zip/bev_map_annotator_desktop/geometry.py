"""GeoJSON category and geometry validation."""
import math
from shapely.geometry import shape
from shapely.validation import explain_validity

CATEGORIES = {'divider': 'LineString', 'boundary': 'LineString', 'stopline': 'LineString',
              'ped_crossing': 'Polygon', 'drivable_area': 'Polygon'}


def validate(annotation):
    if annotation.get('type') != 'FeatureCollection' or not isinstance(annotation.get('features'), list):
        raise ValueError('Expected GeoJSON FeatureCollection')
    for i, feature in enumerate(annotation['features']):
        category = feature['properties']['category']
        geometry = feature['geometry']
        if category not in CATEGORIES or geometry.get('type') != CATEGORIES[category]:
            raise ValueError(f'Feature {i}: category/geometry mismatch')
        rings = geometry['coordinates'] if geometry['type'] == 'Polygon' else [geometry['coordinates']]
        if not rings:
            raise ValueError(f'Feature {i}: empty coordinates')
        for ring in rings:
            if len(ring) < (4 if geometry['type'] == 'Polygon' else 2):
                raise ValueError(f'Feature {i}: too few vertices')
            if any(len(p) != 2 or any(isinstance(x, bool) or not math.isfinite(float(x)) for x in p) for p in ring):
                raise ValueError(f'Feature {i}: require finite XY coordinates')
            if geometry['type'] == 'Polygon' and ring[0] != ring[-1]:
                raise ValueError(f'Feature {i}: polygon ring must be closed')
        g = shape(geometry)
        if g.is_empty or not g.is_valid or not g.is_simple:
            raise ValueError(f'Feature {i} ({category}): {explain_validity(g)}; crossing lines must be fixed')
        if (g.geom_type == 'Polygon' and g.area <= 0) or (g.geom_type == 'LineString' and g.length <= 0):
            raise ValueError(f'Feature {i}: zero-size geometry')


