import copy,json,tempfile,unittest
from pathlib import Path
from app import pixel_to_world,world_to_pixel,save_annotation,Editor
from geometry import validate

class DataTests(unittest.TestCase):
 def test_stopline_is_saved_as_linestring(self):
  feature={'type':'FeatureCollection','features':[{'type':'Feature','properties':{'category':'stopline'},'geometry':{'type':'LineString','coordinates':[[0.,0.],[3.,0.]]}}]}
  with tempfile.TemporaryDirectory() as tmp:
   output=Path(tmp)/'stopline.geojson';save_annotation(feature,output,0);saved=json.loads(output.read_text());self.assertEqual(saved['features'][0]['properties']['category'],'stopline');self.assertEqual(saved['features'][0]['geometry']['type'],'LineString')
 def test_coordinate_roundtrip(self):
  meta={'resolution_m':.15,'minimum_world_xy':[-300,-120],'image_size':[2527,2117]}
  for p in [[0,0],[2526,2116],[123.4,987.6]]:
   q=world_to_pixel(pixel_to_world(p,meta),meta)
   for a,b in zip(p,q):self.assertAlmostEqual(a,b,places=8)
 def test_atomic_save_backup_and_conflict(self):
  annotation=json.loads((Path(__file__).parent/'example/annotations.geojson').read_text());validate(annotation)
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'result.geojson';_,revision=save_annotation(annotation,p,0)
   with self.assertRaises(ValueError):save_annotation(annotation,p,0)
   save_annotation(annotation,p,revision);self.assertEqual(len(list((p.parent/'backups').glob('*.geojson'))),1)
 def test_crossed_polygon_rejected(self):
  with self.assertRaises(ValueError):validate({'type':'FeatureCollection','features':[{'properties':{'category':'drivable_area'},'geometry':{'type':'Polygon','coordinates':[[[0,0],[2,2],[0,2],[2,0],[0,0]]]}}]})

class DesktopTests(unittest.TestCase):
 def test_load_draw_save_undo_redo(self):
  import tkinter as tk
  try:root=tk.Tk()
  except tk.TclError as exc:self.skipTest(f'No desktop display: {exc}')
  root.withdraw();base=Path(__file__).parent
  try:
   with tempfile.TemporaryDirectory() as tmp:
    editor=Editor(root,base/'example/ground_reflectivity.png',base/'example/metadata.json',base/'example/annotations.geojson',Path(tmp)/'output.geojson');root.update_idletasks();editor.fit();self.assertEqual(len(editor.data['features']),85);self.assertTrue(editor.canvas.find_all());self.assertGreater(editor.scale,0)
    editor.category.set('divider');editor.new();editor.current['geometry']['coordinates']=[[0.,0.],[1.,1.]];editor.finish();self.assertEqual(len(editor.data['features']),86);editor.undo();self.assertEqual(len(editor.data['features']),85);editor.redo();self.assertEqual(len(editor.data['features']),86);self.assertTrue(editor.save());self.assertTrue((Path(tmp)/'output.geojson').exists())
  finally:root.destroy()

if __name__=='__main__':unittest.main()
