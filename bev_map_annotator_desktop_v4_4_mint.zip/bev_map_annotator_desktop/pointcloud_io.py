"""Standalone ASCII/binary PCD and KITTI BIN reader."""
from pathlib import Path
from typing import Dict, Tuple
import numpy as np

PCD_DTYPES = {
    ("F", 4): "<f4", ("F", 8): "<f8",
    ("I", 1): "i1", ("I", 2): "<i2", ("I", 4): "<i4",
    ("U", 1): "u1", ("U", 2): "<u2", ("U", 4): "<u4",
}


def read_pcd(path: Path) -> Tuple[Dict[str, np.ndarray], dict]:
    """Read ASCII or uncompressed binary PCD while preserving point order."""
    header_lines = []
    with path.open("rb") as stream:
        while True:
            line = stream.readline()
            if not line:
                raise ValueError("Invalid PCD: DATA line was not found")
            decoded = line.decode("ascii", errors="strict").strip()
            header_lines.append(decoded)
            if decoded.upper().startswith("DATA "):
                payload = stream.read()
                break

    header = {}
    for line in header_lines:
        if not line or line.startswith("#"):
            continue
        key, *values = line.split()
        header[key.upper()] = values

    fields = header.get("FIELDS") or header.get("FIELD")
    if not fields:
        raise ValueError("Invalid PCD: FIELDS is missing")
    sizes = list(map(int, header.get("SIZE", ["4"] * len(fields))))
    types = [v.upper() for v in header.get("TYPE", ["F"] * len(fields))]
    counts = list(map(int, header.get("COUNT", ["1"] * len(fields))))
    points = int((header.get("POINTS") or header.get("WIDTH") or ["0"])[0])
    data_kind = header["DATA"][0].lower()

    if not (len(fields) == len(sizes) == len(types) == len(counts)):
        raise ValueError("FIELDS, SIZE, TYPE and COUNT lengths do not match")

    expanded_names = []
    for name, count in zip(fields, counts):
        expanded_names.extend([name] if count == 1 else [f"{name}_{i}" for i in range(count)])

    if data_kind == "ascii":
        matrix = np.loadtxt(payload.splitlines(), dtype=np.float64, ndmin=2)
        if matrix.shape[1] != len(expanded_names):
            raise ValueError("ASCII PCD column count does not match its header")
        arrays = {name: matrix[:, i] for i, name in enumerate(expanded_names)}
    elif data_kind == "binary":
        dtype_fields = []
        for name, size, kind, count in zip(fields, sizes, types, counts):
            try:
                base = np.dtype(PCD_DTYPES[(kind, size)])
            except KeyError as exc:
                raise ValueError(f"Unsupported PCD field type: TYPE={kind} SIZE={size}") from exc
            dtype_fields.append((name, base) if count == 1 else (name, base, (count,)))
        records = np.frombuffer(payload, dtype=np.dtype(dtype_fields), count=points)
        arrays = {}
        for name, count in zip(fields, counts):
            if count == 1:
                arrays[name] = records[name]
            else:
                for i in range(count):
                    arrays[f"{name}_{i}"] = records[name][:, i]
    elif data_kind == "binary_compressed":
        raise ValueError("binary_compressed PCD is not supported; convert it to ASCII or binary first")
    else:
        raise ValueError(f"Unsupported DATA encoding: {data_kind}")

    actual_points = len(next(iter(arrays.values())))
    if points and actual_points != points:
        raise ValueError(f"Header says {points} points, but file contains {actual_points}")
    metadata = {k.lower(): v for k, v in header.items()}
    metadata["point_count"] = actual_points
    return arrays, metadata


def read_kitti_bin(path: Path) -> Tuple[Dict[str, np.ndarray], dict]:
    """Read KITTI's float32 [x, y, z, reflectance] point format."""
    raw = np.fromfile(path, dtype="<f4")
    if raw.size % 4:
        raise ValueError(f"Invalid KITTI point cloud: {path} does not contain groups of 4 float32 values")
    points = raw.reshape(-1, 4)
    fields = {
        "x": points[:, 0], "y": points[:, 1], "z": points[:, 2],
        "intensity": points[:, 3],
    }
    return fields, {"format": "kitti-bin", "point_count": len(points),
                    "fields": ["x", "y", "z", "intensity"]}


def read_point_cloud(path: Path) -> Tuple[Dict[str, np.ndarray], dict]:
    suffix = path.suffix.lower()
    if suffix == ".pcd":
        fields, metadata = read_pcd(path)
        metadata["format"] = "pcd"
        return fields, metadata
    if suffix == ".bin":
        return read_kitti_bin(path)
    raise ValueError(f"Unsupported point-cloud extension '{suffix}'; expected .pcd or KITTI .bin")


